import config from './config.json' assert { type: 'json' };

export async function onRequest(context) {
  const ua = context.request.headers.get("user-agent") || "";
  const ip = context.request.headers.get("cf-connecting-ip") || "";
  let status = 200;
  let msg = config.messages["200"];

  if (!config.whitelist.some(item => ua.includes(item) || ip === item)) {
    if (config.blockedUserAgents.some(pattern => new RegExp(pattern, "i").test(ua))) {
      status = 403;
      msg = config.messages["403"];
    } else if (ua.length < config.minUAlength) {
      status = 418;
      msg = config.messages["418"];
    }
  }

  const key = `rl:${ip}`;
  const count = parseInt(await context.env.RATELIMIT.get(key)) || 0;
  if (count >= config.rateLimit.maxRequests) {
    status = 429;
    msg = config.messages["429"];
  } else {
    await context.env.RATELIMIT.put(key, count + 1, { expirationTtl: config.rateLimit.windowSeconds });
  }

  const html = `<html><body style="text-align:center;font-family:sans-serif;background:#111;color:#fff;padding:50px;"><img src="https://http.cat/${status}" alt="${status}" style="max-width:400px;" /><h1>${msg}</h1><footer style="color:#888;margin-top:20px;">made by:aø in: 🇦🇹 (credits)</footer></body></html>`;

  return new Response(html, {
    status,
    headers: { "content-type": "text/html" }
  });
}